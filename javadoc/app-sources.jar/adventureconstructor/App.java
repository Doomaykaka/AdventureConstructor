package adventureconstructor;

import javax.swing.SwingUtilities;

import adventureconstructor.gui.GameUI;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameUI ui = new GameUI();
            ui.setLocationRelativeTo(null);
            ui.setVisible(true);
        });
    }
}
